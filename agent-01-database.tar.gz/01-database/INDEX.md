# Agent 01 — Database & Data Structures

**Role:** Data engineer. **Owns the foundation every other window reads.**
**Baseline health:** 5.8 / 10 (set 2026-06-13).

## Owns
- `backend/models.py` — ORM tables (User, CommandHistory, RefreshSession)
- `backend/database.py` — async SQLAlchemy engine + session (SQLite↔Postgres)
- `backend/migrations/` — Alembic env, template, `0001_initial`
- `backend/alembic.ini`
- `modules/_shared/db.py` — the CLI's SQLite helper (shipped here as `_shared_db.py`)

## Depends on / feeds
- Feeds: Backend Core (schemas), AI, Knowledge (they read the schema).
- A schema change here ripples → flag under Cross-Window Impact every time.

## This agent's standing job (per WINDOW_DIRECTIVES)
Document → Break down → Harden → Health report, every session. Obey RULES.md.
