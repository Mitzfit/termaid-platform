/* TermAId web — client.
   No framework, no build step: just runs. The terminal lexer mirrors the
   token categories TermAId highlights in its prompt_toolkit REPL. */
(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const out = $("output");
  const promptInput = $("prompt");
  const statusEl = $("status");

  let token = localStorage.getItem("termaid_token") || "";
  let username = localStorage.getItem("termaid_user") || "";
  const history = [];
  let histIdx = -1;
  let ws = null;

  // ---- tiny lexer: colorize a /command line the way the REPL does ----------
  function lexCommandLine(line) {
    const parts = line.split(/(\s+)/);
    let seenCmd = false;
    return parts.map((p) => {
      if (/^\s+$/.test(p)) return p;
      if (!seenCmd && p.startsWith("/")) {           // /mod.sub
        seenCmd = true;
        const m = p.match(/^\/([\w-]+)(\.[\w-]+)?$/);
        if (m) {
          const mod = `<span class="tok-command">/${m[1]}</span>`;
          const sub = m[2] ? `<span class="tok-subcmd">${m[2]}</span>` : "";
          return mod + sub;
        }
        return `<span class="tok-command">${esc(p)}</span>`;
      }
      if (/^-{1,2}[\w-]+$/.test(p)) return `<span class="tok-flag">${esc(p)}</span>`;
      if (/^-?\d+(\.\d+)?$/.test(p)) return `<span class="tok-number">${esc(p)}</span>`;
      if (/[\/\\][\w.\/\\-]+/.test(p)) return `<span class="tok-path">${esc(p)}</span>`;
      if (/^["'].*["']$/.test(p)) return `<span class="tok-string">${esc(p)}</span>`;
      if (/[|&;{}()<>]/.test(p)) return `<span class="tok-symbol">${esc(p)}</span>`;
      return esc(p);
    }).join("");
  }
  function esc(s) {
    return s.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
  }

  // ---- output rendering ----------------------------------------------------
  function addEcho(line) {
    const el = document.createElement("div");
    el.className = "line echo";
    el.innerHTML = `<span class="sigil">you →</span> ` +
      (line.startsWith("/") ? lexCommandLine(line) : esc(line));
    out.appendChild(el);
    scroll();
  }
  function addResult(payload) {
    const el = document.createElement("div");
    const kind = payload.ok === false ? "err" : (payload.type || payload.kind || "chat");
    el.className = "line " + (kind === "command" ? "" : kind);
    el.textContent = payload.output || "";
    out.appendChild(el);
    scroll();
  }
  function addSys(text) {
    const el = document.createElement("div");
    el.className = "line sys";
    el.textContent = text;
    out.appendChild(el);
    scroll();
  }
  function scroll() { out.scrollTop = out.scrollHeight; }

  // ---- websocket -----------------------------------------------------------
  function connect() {
    const proto = location.protocol === "https:" ? "wss" : "ws";
    const url = `${proto}://${location.host}/ws${token ? "?token=" + encodeURIComponent(token) : ""}`;
    ws = new WebSocket(url);
    ws.onopen = () => setStatus(null, true);
    ws.onmessage = (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.type === "ready") {
        setStatus(`${msg.commands} commands · ${username || "guest"}`, true);
        addSys(`TermAId web ready — ${msg.commands} commands across 121 modules. Type /help or click a command.`);
        return;
      }
      addResult(msg);
    };
    ws.onclose = () => { setStatus("disconnected — retrying…", false); setTimeout(connect, 1500); };
    ws.onerror = () => ws.close();
  }
  function setStatus(text, live) {
    if (text != null) statusEl.textContent = text;
    statusEl.classList.toggle("live", !!live);
  }

  function run(line) {
    line = line.trim();
    if (!line) return;
    addEcho(line);
    history.push(line); histIdx = history.length;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(line);
    } else {
      // fallback to REST if the socket is down
      fetch("/api/exec", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) },
        body: JSON.stringify({ line }),
      }).then((r) => r.json()).then(addResult).catch(() => addSys("Request failed."));
    }
  }

  // ---- prompt handlers -----------------------------------------------------
  $("promptForm").addEventListener("submit", (e) => {
    e.preventDefault();
    run(promptInput.value);
    promptInput.value = "";
  });
  promptInput.addEventListener("keydown", (e) => {
    if (e.key === "ArrowUp") {
      if (histIdx > 0) { histIdx--; promptInput.value = history[histIdx]; e.preventDefault(); }
    } else if (e.key === "ArrowDown") {
      if (histIdx < history.length - 1) { histIdx++; promptInput.value = history[histIdx]; }
      else { histIdx = history.length; promptInput.value = ""; }
      e.preventDefault();
    }
  });

  // ---- palette -------------------------------------------------------------
  let catalog = [];
  function renderPalette(filterText) {
    const list = $("paletteList");
    const q = (filterText || "").toLowerCase();
    const groups = {};
    for (const c of catalog) {
      if (q && !c.command.toLowerCase().includes(q)) continue;
      (groups[c.module] ||= []).push(c);
    }
    list.innerHTML = "";
    const names = Object.keys(groups).sort();
    if (!names.length) { list.innerHTML = `<div class="line sys" style="padding:.5rem">no match</div>`; return; }
    for (const mod of names) {
      const head = document.createElement("div");
      head.className = "pl-group";
      head.innerHTML = `<span class="g-name">${esc(mod)}</span><span class="g-count">${groups[mod].length}</span>`;
      list.appendChild(head);
      for (const c of groups[mod]) {
        const b = document.createElement("button");
        b.className = "pl-cmd";
        b.title = c.description || c.command;
        b.innerHTML = `<span class="pc-mod">/${esc(c.module)}</span><span class="pc-dot">.</span>${esc(c.sub)}`;
        b.addEventListener("click", () => {
          promptInput.value = "/" + c.command + " ";
          promptInput.focus();
        });
        list.appendChild(b);
      }
    }
  }
  $("filter").addEventListener("input", (e) => renderPalette(e.target.value));

  fetch("/api/commands").then((r) => r.json()).then((d) => {
    catalog = d.commands || [];
    renderPalette("");
  }).catch(() => addSys("Could not load command catalog."));

  // ---- auth ----------------------------------------------------------------
  const modal = $("authModal");
  function refreshWho() {
    $("who").textContent = username ? username : "";
    $("authBtn").textContent = username ? "Log out" : "Log in";
  }
  $("authBtn").addEventListener("click", () => {
    if (username) {  // log out
      token = ""; username = "";
      localStorage.removeItem("termaid_token");
      localStorage.removeItem("termaid_user");
      refreshWho();
      if (ws) ws.close();
      return;
    }
    modal.classList.remove("hidden");
  });
  $("mClose").addEventListener("click", () => modal.classList.add("hidden"));

  function doAuth(path) {
    const u = $("mUser").value.trim(), p = $("mPass").value;
    $("authErr").textContent = "";
    fetch("/api/" + path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: u, password: p }),
    }).then(async (r) => {
      const d = await r.json();
      if (!r.ok) throw new Error(d.detail || "Failed");
      token = d.token; username = d.username;
      localStorage.setItem("termaid_token", token);
      localStorage.setItem("termaid_user", username);
      modal.classList.add("hidden");
      refreshWho();
      if (ws) ws.close();  // reconnect with token so history attaches
    }).catch((err) => { $("authErr").textContent = err.message; });
  }
  $("mLogin").addEventListener("click", () => doAuth("login"));
  $("mRegister").addEventListener("click", () => doAuth("register"));

  // ---- boot ----------------------------------------------------------------
  refreshWho();
  connect();
  promptInput.focus();
})();
