"""
server.py — FastAPI web tier for TermAId.

Endpoints
  GET  /api/health            liveness + command count
  GET  /api/commands          the full command catalog (palette data)
  GET  /api/modules           module load status
  POST /api/register          {username, password} -> creates a web user
  POST /api/login             {username, password} -> {token}
  POST /api/exec              {line} -> runs one command/chat line
  GET  /api/history           recent history for the caller
  WS   /ws                    interactive terminal stream
  GET  /                      serves the frontend

Auth is a Bearer token in the Authorization header. It is optional for
/api/exec (anonymous users can run commands and their history logs with
user_id NULL) but you can flip REQUIRE_AUTH to lock it down.

Run:
  pip install -r requirements.txt
  TERMAID_ROOT=/path/to/termaid-complete-windows uvicorn server:app --reload
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Header, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import db
from bridge import get_engine

REQUIRE_AUTH = os.environ.get("REQUIRE_AUTH", "0") == "1"
FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"

app = FastAPI(title="TermAId Web", version="1.0.0")


@app.on_event("startup")
def _startup() -> None:
    db.init_db()
    get_engine()  # warm the module cache so the first request is fast


# --- helpers -----------------------------------------------------------------
def _uid(authorization: Optional[str]) -> Optional[int]:
    if not authorization or not authorization.lower().startswith("bearer "):
        return None
    return db.user_for_token(authorization.split(" ", 1)[1].strip())


def _require(authorization: Optional[str]) -> Optional[int]:
    uid = _uid(authorization)
    if REQUIRE_AUTH and uid is None:
        raise HTTPException(status_code=401, detail="Login required")
    return uid


# --- schemas -----------------------------------------------------------------
class Creds(BaseModel):
    username: str
    password: str


class ExecBody(BaseModel):
    line: str


# --- meta --------------------------------------------------------------------
@app.get("/api/health")
def health():
    eng = get_engine()
    return {"status": "ok", "commands": len(eng.commands()), "load_errors": eng.load_errors}


@app.get("/api/commands")
def commands():
    return {"commands": get_engine().catalog()}


@app.get("/api/modules")
def modules():
    return {"modules": get_engine().modules_info()}


# --- auth --------------------------------------------------------------------
@app.post("/api/register")
def register(creds: Creds):
    if len(creds.username) < 3 or len(creds.password) < 8:
        raise HTTPException(400, "Username >=3 chars, password >=8 chars.")
    uid = db.create_user(creds.username, creds.password)
    if uid is None:
        raise HTTPException(409, "Username already taken.")
    return {"token": db.new_session(uid), "username": creds.username}


@app.post("/api/login")
def login(creds: Creds):
    uid = db.verify_user(creds.username, creds.password)
    if uid is None:
        raise HTTPException(401, "Invalid username or password.")
    return {"token": db.new_session(uid), "username": creds.username}


# --- core --------------------------------------------------------------------
@app.post("/api/exec")
def exec_line(body: ExecBody, authorization: Optional[str] = Header(default=None)):
    uid = _require(authorization)
    result = get_engine().execute(body.line)
    db.log_command(uid, body.line, result.kind, result.ok)
    return JSONResponse({
        "ok": result.ok,
        "kind": result.kind,
        "command": result.command,
        "output": result.output,
    })


@app.get("/api/history")
def history(authorization: Optional[str] = Header(default=None)):
    uid = _uid(authorization)
    return {"history": db.recent_history(uid)}


# --- websocket terminal ------------------------------------------------------
@app.websocket("/ws")
async def ws_terminal(ws: WebSocket):
    await ws.accept()
    eng = get_engine()
    token = ws.query_params.get("token", "")
    uid = db.user_for_token(token) if token else None
    await ws.send_json({"type": "ready", "commands": len(eng.commands())})
    try:
        while True:
            line = (await ws.receive_text()).strip()
            if not line:
                continue
            result = eng.execute(line)
            db.log_command(uid, line, result.kind, result.ok)
            await ws.send_json({
                "type": result.kind,
                "ok": result.ok,
                "command": result.command,
                "output": result.output,
            })
    except WebSocketDisconnect:
        return


# --- frontend ----------------------------------------------------------------
if FRONTEND_DIR.is_dir():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

    @app.get("/")
    def index():
        return FileResponse(str(FRONTEND_DIR / "index.html"))
