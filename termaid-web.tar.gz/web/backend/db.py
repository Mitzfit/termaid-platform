"""
db.py — the web app's own database.

TermAId modules already use SQLite for their domain data (auth, dbkeys,
etc.). This file adds the *web tier's* persistence: who is logged into
the web UI, and what they ran. It is intentionally small and uses only
the stdlib so it runs anywhere.

WHY START WITH SQLITE: zero setup, one file, already proven across the
rest of the project. The schema below is deliberately written in plain
ANSI-ish SQL so the move to Postgres is mechanical — see README.md
("Database: SQLite -> Postgres") for the exact swap. The only Postgres
edits are: AUTOINCREMENT -> SERIAL/IDENTITY, and "?" placeholders ->
"%s" (psycopg). Keep all queries in this one file so that swap stays
contained.
"""
from __future__ import annotations

import os
import sqlite3
import secrets
import hashlib
import time
from pathlib import Path
from typing import Optional

DB_PATH = Path(os.environ.get("WEB_DB_PATH", Path(__file__).parent / "termaid_web.db"))


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db() -> None:
    conn = _conn()
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS web_users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            username      TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            salt          TEXT NOT NULL,
            created_at    REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS web_sessions (
            token       TEXT PRIMARY KEY,
            user_id     INTEGER NOT NULL,
            created_at  REAL NOT NULL,
            expires_at  REAL NOT NULL,
            FOREIGN KEY (user_id) REFERENCES web_users(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS command_history (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            line        TEXT NOT NULL,
            kind        TEXT NOT NULL,
            ok          INTEGER NOT NULL,
            ran_at      REAL NOT NULL,
            FOREIGN KEY (user_id) REFERENCES web_users(id) ON DELETE SET NULL
        );

        CREATE INDEX IF NOT EXISTS idx_history_user ON command_history(user_id, ran_at);
        """
    )
    conn.commit()
    conn.close()


# --- password helpers (PBKDF2, stdlib only) ----------------------------------
def _hash_password(password: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode(), salt.encode(), 200_000
    ).hex()


def create_user(username: str, password: str) -> Optional[int]:
    salt = secrets.token_hex(16)
    pw = _hash_password(password, salt)
    conn = _conn()
    try:
        cur = conn.execute(
            "INSERT INTO web_users (username, password_hash, salt, created_at) "
            "VALUES (?, ?, ?, ?)",
            (username, pw, salt, time.time()),
        )
        conn.commit()
        return cur.lastrowid
    except sqlite3.IntegrityError:
        return None  # username taken
    finally:
        conn.close()


def verify_user(username: str, password: str) -> Optional[int]:
    conn = _conn()
    row = conn.execute(
        "SELECT id, password_hash, salt FROM web_users WHERE username = ?",
        (username,),
    ).fetchone()
    conn.close()
    if not row:
        return None
    if secrets.compare_digest(row["password_hash"], _hash_password(password, row["salt"])):
        return row["id"]
    return None


# --- sessions ----------------------------------------------------------------
def new_session(user_id: int, ttl_seconds: int = 7 * 24 * 3600) -> str:
    token = secrets.token_urlsafe(32)
    now = time.time()
    conn = _conn()
    conn.execute(
        "INSERT INTO web_sessions (token, user_id, created_at, expires_at) "
        "VALUES (?, ?, ?, ?)",
        (token, user_id, now, now + ttl_seconds),
    )
    conn.commit()
    conn.close()
    return token


def user_for_token(token: str) -> Optional[int]:
    if not token:
        return None
    conn = _conn()
    row = conn.execute(
        "SELECT user_id, expires_at FROM web_sessions WHERE token = ?", (token,)
    ).fetchone()
    conn.close()
    if not row or row["expires_at"] < time.time():
        return None
    return row["user_id"]


def end_session(token: str) -> None:
    conn = _conn()
    conn.execute("DELETE FROM web_sessions WHERE token = ?", (token,))
    conn.commit()
    conn.close()


# --- history -----------------------------------------------------------------
def log_command(user_id: Optional[int], line: str, kind: str, ok: bool) -> None:
    conn = _conn()
    conn.execute(
        "INSERT INTO command_history (user_id, line, kind, ok, ran_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (user_id, line, kind, 1 if ok else 0, time.time()),
    )
    conn.commit()
    conn.close()


def recent_history(user_id: Optional[int], limit: int = 50) -> list[dict]:
    conn = _conn()
    rows = conn.execute(
        "SELECT line, kind, ok, ran_at FROM command_history "
        "WHERE user_id IS ? ORDER BY ran_at DESC LIMIT ?",
        (user_id, limit),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]
