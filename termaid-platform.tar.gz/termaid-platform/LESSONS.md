# LESSONS — the team's running memory

Every window appends here; the main thread and every new window read it first.
This is how we "learn as a team" despite windows not sharing live memory:
written knowledge > tribal memory.

Format:  `YYYY-MM-DD · <window> · <lesson / decision / gotcha>`

## Seeded (workflow decisions so far)
- 2026-06-13 · main · Windows are isolated; the orchestrator carries work between
  them and the master index is the single source of truth.
- 2026-06-13 · main · Standard hand-back contract (HANDOFF_TEMPLATE) makes
  integration mechanical; the Cross-Window Impact line is the most important field.
- 2026-06-13 · main · Code is documented per CODE_STYLE.md, attributed to Misfit,
  commented as each window is worked (not all 120 modules at once).
- 2026-06-13 · main · Every session: Document → Break down → Harden → Health report.
- 2026-06-13 · main · Health reports are scored and trend-tracked so we can prove
  the platform is improving, not just changing.

## Process improvements (add as we find them)
- 2026-06-13 · main · Two rule layers: UNIVERSAL (permanent) + LOCAL (session,
  promotable). Local rules that earn their keep get promoted in the hand-back.
- 2026-06-13 · main · Every session opens with a kickoff brainstorm (brain-dump →
  review → priorities → Definition of Done) to set a baseline and stay on task.
- 2026-06-13 · main · Guard against process bloat: small tasks use the 60-second
  brainstorm fast path; process should accelerate work, never gate it.
